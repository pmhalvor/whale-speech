import tensorflow_hub as hub
import tensorflow as tf
import numpy as np

model = hub.load("https://tfhub.dev/google/humpback_whale/1")
score_fn = model.signature["score"]

signal = np.load("data/audio/butterworth/2016/12/20161221T004930-005030-9182.npy")

waveform1 = np.expand_dims(signal, axis=1)
waveform_exp = tf.expand_dims(waveform1, 0)

results = score_fn(
    waveform=waveform_exp,
    context_step_samples=10_000
)["scores"]

print(waveform_exp.shape)
print(results.shape)