# Learn Lightweight Architecture Decision Records (LADR)
Lightweight Architecture Decision Records (LADR) are a way to manage and communicate software and deployment design decisions transparently as code, without overly heavy focus on producing design artifacts.

## Further reading
https://github.com/joelparkerhenderson/architecture_decision_record